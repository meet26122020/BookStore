const express = require('express');
const bodyParser = require('body-parser');

const mongoose = require('mongoose');

const app = express();
const port = 8000;

// Connect to MongoDB using Mongoose
mongoose.connect('mongodb://127.0.0.1:27017/Book-Store')
    .then(() => console.log(' MongoDB Connected'))
    .catch(err => console.error('Failed to connect to MongoDB', err));

// Define a Mongoose schema
const userSchema = new mongoose.Schema({
    Bookname: {
        type: String,
        required: true
    },
    Price: {
        type: Number,
        required:true
    },
    Author: {
        type: String,
        required: true
    },
    Language: {
        type: String,
        required: true
    },
    Quantity: {
        type: Number,
        required:true
    }
},{
    timestamps:true
}
);

// Create a Mongoose model
const User = mongoose.model('Book', userSchema);

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', async (req, res) => {
    try {
        const users = await User.find();
        res.render('index', { users: users });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/addUser', async (req, res) => {
    try {
        const newUser = new User({
            Bookname: req.body.Bookname,
            Price: req.body.Price,
            Author: req.body.Author,
            Language:req.body.Language,
            Quantity: req.body.Quantity
        });
        await newUser.save();
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});


app.get('/deleteData/:id', async (req, res) => {
    try {
        const id = req.params.id;
        await User.deleteOne({ _id: id });
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});


app.get('/editData/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const user = await User.findOne({ _id: id });
        res.render('edit', { editData: user });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});


app.post('/editinfo/:id', async (req, res) => {
    try {
        const id = req.params.id;
        await User.updateOne({ _id: id }, {
            Bookname: req.body.Bookname,
            Price: req.body.Price,
            Author: req.body.Author,
            Language:req.body.Language,
            Quantity: req.body.Quantity
        });
        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});


app.listen(port, () => {
    console.log(`Server Started at ${port}`);
});
